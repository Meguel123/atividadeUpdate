namespace atividadeF
{
    using MySql.Data.MySqlClient;
    using System.Data;
    using static System.Windows.Forms.VisualStyles.VisualStyleElement;

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection connection = new MySqlConnection();
        MySqlCommand command = new MySqlCommand();

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;User Id=root;database=db_usuarios;password=root;";
            string query = "SELECT nome, email FROM tb_usuarios WHERE id = @id";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // Executa um comando (ex: INSERT, UPDATE, DELETE)
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", textBox1.Text);
                    cmd.ExecuteNonQuery();

                    MySqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        string nome = reader["nome"].ToString();
                        string email = reader["email"].ToString();
                        lab.Text = $"Nome: {nome} | Email: {email}";
                    }
                    else
                    {
                        lab.Text = "Nenhum dado encontrado.";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;User Id=root;database=db_usuarios;password=root;";
            string query = "UPDATE tb_usuarios SET nome = @nome, email = @email WHERE id = @id";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@nome", textBox2.Text);
                    cmd.Parameters.AddWithValue("@email", textBox3.Text);
                    cmd.Parameters.AddWithValue("@id", textBox1.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cadastro realizado com sucesso!!!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro: " + ex.Message);
                }
                //conn.Close();
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void lab_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
           valida��o exibe = new valida��o();
            this.Hide();
            exibe.ShowDialog();
        }
    }
}
